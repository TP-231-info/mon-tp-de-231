#include<stdio.h>
#define Max 10 //taille de la matrice
void saisir_matrice(int matrice[Max][Max],int lignes, int colonnes) {
    for(int i=0; i<lignes; i++) {
        for(int j=0; j<colonnes; j++) {
            printf("Entrer un nombre [%d][%d]:",i+1,j+1);
            scanf("%d",&matrice[i][j]);
        }
    }
}
void affiche_matrice(int matrice[Max][Max],int lignes, int colonnes) {
    for(int i=0; i<lignes; i++) {
        for(int j=0; j<colonnes; j++) {
            printf("%d",matrice[i][j]);
        }
        printf("\n");
    }

}
void multiplication(int matrice1[Max][Max],int matrice2[Max][Max],int resultat[Max][Max],int lignes,int colonnes,int n) {
    for(int i=0; i<lignes; i++) {
        for(int j=0; j<colonnes; j++) {
            resultat[i][j]=0 ; //initialisé resultat a for
            for(int k=0; k<n; k++) {
                resultat[i][j]=matrice1[i][k]*matrice2[k][i];//calcul du produit
            }
        }
    }
}
int main () {
    int lignes,colonnes,n;
    int matrice1[Max][Max];
    int matrice2[Max][Max];
    int resultat[Max][Max];
//dimension de la première matrice
    printf("Entrer le nombre de lignes de la matrice1 : \n ");
    scanf("%d",&lignes);
    printf("Entrer le nombre de colonnes de la matrice1(et ligne de matrice2): \n");
    scanf("%d",&n);
//dimension de la deuxième matrice 2
    printf("Entrer la matrice 2:\n");
    scanf("%d",&colonnes);
    // saisir les matrice s
    saisir_matrice(matrice1, lignes, colonnes);
    printf("Entrer la matrice 2 :\n");
    saisir_matrice(matrice2, lignes, colonnes);
    //le produit
    multiplication(matrice1,matrice2,resultat,lignes, colonnes,n);
    //affichage
    printf("le résultats est :\n");
    affiche_matrice(resultat,lignes, colonnes);
    return 0;
}