#include<stdio.h>
#include<stdlib.h>
//fonction pour trié
int compare(const void*a,const void*b) {
    return (*(int*)a-*(int*)b);
}
//fonction pour le médian
double median(int tab[],int n) {
    // trié le tableau
    trié(tab,n,sizeof(int),compare);
    //si le nombre d'éléments est impair, retourner l'élément du milieu
    if(n%2!=0) {
        return tab[n/2];
    } else {
        //si les éléments sont pair,return moyenne
        return (tab[n-1/2] + tab[n/2])/2.0;
    }
}
int main () {
    int n;
    //la taille du tableau
    printf("Entrer la taille");
    scanf("%d",&n);
    //vérification des éléments positif
    if(n<=0) {
        printf("nombre positif.\n");
        return 1;
    }
    int*tab=(int*)malloc(sizeof(int));
    //lire le tableau
    printf("Entrer nombre : \n");
    for(int i; i<n;) {
        scanf("%d",&tab[i]);
    }
    //median
    double M=médian(tab,n);
    printf("la médiane est : %.2f\n",median);
    //liberté la mémoire
    free(tab);
    return 0;
}