#include<stdio.h>
#define Max 10 //taille de la matrice
void saisir_matrice(int matrice[Max][Max],int lignes, int colonnes){
     for(int i=0;i<lignes;i++){
       for(int j=0;j<colonnes;j++){
          printf("Entrer un nombre [%d][%d]:",i+1,j+1);
          scanf("%d",&matrice[i][j]);
       }
     }
}
void affiche_matrice(int matrice[Max][Max],int lignes, int colonnes){
     for(int i=0;i<lignes;i++){
         for(int j=0;j<colonnes;j++){
            printf("%d",matrice[i][j]);
         }
          printf("\n");
     }
     
}
void addition(int matrice1[Max][Max],int matrice2[Max][Max],int resultat[Max][Max],int lignes,int colonnes){
  for(int i=0;i<lignes;i++){
     for(int j=0;j<colonnes;j++){
        resultat[i][j]=matrice1[i][j] + matrice2[i][j];
     }
  }
}
int main (){
 int lignes,colonnes;
 int matrice1[Max][Max];
 int matrice2[Max][Max];
 int resultat[Max][Max];
 printf("Entrer le nombre de lignes : \n ");
 scanf("%d",&lignes);
 printf("Entrer le nombre de colonnes: \n");
 scanf("%d",&colonnes);
  printf("Entrer la matrice 1:\n");
  saisir_matrice(matrice1, lignes, colonnes);
  printf("Entrer la matrice 2 :\n");
  saisir_matrice(matrice2, lignes, colonnes);
  addition(matrice1,matrice2,resultat,lignes, colonnes);
  printf("le résultats est :\n");
  affiche_matrice(resultat,lignes, colonnes);
  return 0;
  }