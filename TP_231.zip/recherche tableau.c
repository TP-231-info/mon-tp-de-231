#include<stdio.h>
#define Max 10//taille maximale du tableau
int main() {
    int tab[Max];
    int n;
    printf("Entrer un nombre: \n");
    scanf("%d",&n);
    //remplir le tableau
    printf("Remplir le tableau : \n");
    for(int i=0; i<Max; i++) {
        printf("Entrer un nombre%d:",i+1);
        scanf("%d",&tab[i]);
    }
    //recherche dans le tableau
    printf("recherche : \n");
    for(int i=0; i<Max; i++) {
        if(tab[i]==n) {
            printf("non trouvé\n");
        } else {
            printf("trouvé \n");
        }
    }
    printf("\n");
    return 0;
}