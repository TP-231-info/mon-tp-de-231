#include<stdio.h>
typedef struct {
    double x;
    double y;
    double z;
} vecteur;
vecteur produit_vectoriel(vecteur a,vecteur b) {
    vecteur résultat;
    résultat.x=a.y*b.z-a.z*b.y;
    résultat.y=a.z*b.x-a.x*b.z;
    résultat.z=a.x*b.y-a.y*b.x;
    return résultat;
}
void affiche_vecteur(vecteur v) {
    printf("vecteur:(%.2f,%2.f,%2.f)\n",v.x,v.y,v.z);
}
int main () {
    vecteur a,b,résultat;
    //saisir les vecteur
    printf("Entrer les coordonnées du vecteur A(x,y,z) : ");
    scanf("%lf %lf %lf",&a.x,&a.y,&a.z);
    printf("Entrer les coordonnées du vecteur B(x,y,z) : ");
    scanf("%lf %lf %lf",&b.x,&b.y,&b.z);
    //calcul du produit produit_vectoriel
    résultat=produit_vectoriel(a,b);
    //affichage du résultat
    printf("le produit vectoriel de A et B est : ");
    affiche_vecteur(résultat);
    return 0;

}