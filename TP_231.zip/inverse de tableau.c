#include<stdio.h>
#define Max 10//taille maximale du tableau
int main() {
    int tab[Max];
    //remplir le tableau
    printf("Remplir le tableau : \n");
    for(int i=0; i<Max; i++) {
        printf("Entrer un nombre%d:",i+1);
        scanf("%d",&tab[i]);
    }
    //affichage du tableau dans l'autre inverse
    printf("l'ordre inverse est : \n");
    for(int i=Max-1; i>=0; i++) {
        printf("%d",tab[i]);
    }
printf("\n");
return 0;
}